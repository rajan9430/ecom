<?php // Start PHP tag

class Db // Define Db class
{

    private $host = 'localhost'; // Define database host
    private $username = 'root'; // Define database username
    private $password = ''; // Define database password
    private $database = 'shubham_ecom'; // Define database name
    protected $db; // Define protected property db for database connection

    public function __construct() // Constructor method
    {
        try { // Try establishing database connection
            //if it is success
            $dsn = "mysql:host={$this->host}; dbname={$this->database};"; // Define DSN for PDO connection
            $option = array(PDO::ATTR_PERSISTENT); // Define options array

            $this->db = new PDO($dsn, $this->username, $this->password, $option); // Create new PDO instance
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Set error mode to exception
        } catch (PDOException $e) { // Catch any PDOException
            // if it is getting any error
            echo "Connection Error: " . $e->getMessage(); // Echo error message
            exit; // Exit script
        }
    }
}
