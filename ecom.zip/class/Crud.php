<?php // Start PHP tag
require_once('Db.php'); // Include Db.php file

class Crud extends Db // Create Crud class extending Db class
{
    // $insert_data = array( // Commented out code for inserting data
    //     'username' => 'Rajan  Tiwari',
    //     'pass' => $password,
    // );

    public function insert($table_name, $data) // Insert method
    {
        if (!empty($data)) { // Check if data is not empty
            $fields = $placeholder = []; // Initialize fields and placeholder arrays

            foreach ($data as $field => $value) { // Iterate through data
                $fields[] = $field; // Add field to fields array
                $placeholder[] = ":{$field}"; // Add placeholder to placeholder array
            }
        }

        $sql = "INSERT INTO {$table_name} (" . implode(',', $fields) . ") VALUES(" . implode(',', $placeholder) . ")"; // Construct SQL query
        $stmt = $this->db->prepare($sql); // Prepare SQL statement

        try { // Try executing SQL statement
            $this->db->beginTransaction(); // Begin transaction
            $stmt->execute($data); // Execute SQL statement with data
            $insert_id = $this->db->lastInsertId(); // Get last inserted ID
            $this->db->commit(); // Commit transaction
            return $insert_id; // Return inserted ID
        } catch (PDOException $e) { // Catch any PDOException
            echo "Error: " . $e->getMessage(); // Echo error message
        }
    }

    public function slugify($text, $slug_url, $table_name) // Slugify method
    {
        //preg_replace(patterns, replacements, input, limit)
        $text = preg_replace('/[^a-z0-9]+/i', '-', strtolower($text)); // Replace non-alphanumeric characters with hyphens

        $query = "SELECT $slug_url FROM $table_name WHERE $slug_url LIKE '$text%'"; // Construct SQL query
        $stmt = $this->db->prepare($query); // Prepare SQL statement

        $stmt->execute(); // Execute SQL statement
        if ($stmt->rowCount() > 0) { // Check if row count is greater than 0
            $result = $stmt->fetchAll(); // Fetch all results
            foreach ($result as $row) { // Iterate through results
                $data[] = $row[$slug_url]; // Add slug URLs to data array
            }

            if (in_array($text, $data)) { // Check if text is in data array
                $count = 0; // Initialize count variable
                while (in_array(($text . '-' . ++$count), $data)); // Increment count until unique slug is found
                $text = $text . '-' . $count; // Append count to text
            }
        }

        return $text; // Return slugified text
    }

    public function get($table_name, $offset, $records_per_page) // Get method
    {
        $sql = "SELECT * FROM $table_name LIMIT $offset, $records_per_page"; // Construct SQL query
        // prepare our query
        $stmt = $this->db->prepare($sql); // Prepare SQL statement
        // executation our prepared method
        $stmt->execute(); // Execute SQL statement
        //fetch all data from the table
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC); // Fetch all results

        return $result; // Return results
    }

    public function custom_get($table_name, $where = '', $fetch_type = "fetchAll") // Custom get method
    {
        $sql = "SELECT * FROM $table_name "; // Construct SQL query
        if (!empty($where)) { // Check if where condition is not empty
            $sql .= $where; // Append where condition to SQL query
        }
        // prepare our query
        $stmt = $this->db->prepare($sql); // Prepare SQL statement
        // executation our prepared method
        $stmt->execute(); // Execute SQL statement

        if ($fetch_type == "fetchAll") { // Check fetch type
            //fetch all data from the table
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC); // Fetch all results
        }
        if ($fetch_type == "fetch") { // Check fetch type
            //fetch all data from the table
            $result = $stmt->fetch(PDO::FETCH_ASSOC); // Fetch single result
        }
        return $result; // Return result
    }

    public function query($query, $where = '', $fetch_type = "fetchAll") // Custom get method
    {
       
        // prepare our query
        $stmt = $this->db->prepare($query); // Prepare SQL statement
        // executation our prepared method
        $stmt->execute(); // Execute SQL statement

        if ($fetch_type == "fetchAll") { // Check fetch type
            //fetch all data from the table
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC); // Fetch all results
        }
        if ($fetch_type == "fetch") { // Check fetch type
            //fetch all data from the table
            $result = $stmt->fetch(PDO::FETCH_ASSOC); // Fetch single result
        }
        return $result; // Return result
    }

    public function pagination($table, $no_of_records_per_page) // Pagination method
    {
        $query = "SELECT COUNT(*) FROM $table"; // Construct SQL query
        $stmt = $this->db->prepare($query); // Prepare SQL statement
        $stmt->execute(); // Execute SQL statement
        $total_records = $stmt->fetchColumn(); // Fetch total records
        $total_pages = ceil($total_records / $no_of_records_per_page); // Calculate total pages

        return $total_pages; // Return total pages
    }
    // new chaining method

    public function where() // Where method
    {
        " WHERE "; // Return WHERE
        return $this; // Return current object
    }

    public function update($table, $data, $where) // Update method
    {
        if (!empty($data)) { // Check if data is not empty
            $fields = ''; // Initialize fields variable
            $x = 1; // Initialize counter variable
            $fieldscount = count($data); // Get count of data array
            foreach ($data as $field => $value) { // Iterate through data array
                $fields .= "{$field}=:{$field}"; // Append field to fields
                if ($x < $fieldscount) { // Check if not last field
                    $fields .= ", "; // Add comma
                }
                $x++; // Increment counter
            }
        }
        $sql = "UPDATE $table SET {$fields} $where"; // Construct SQL query
        $stmt = $this->db->prepare($sql); // Prepare SQL statement
        try { // Try executing SQL statement
            $this->db->beginTransaction(); // Begin transaction
            $stmt->execute($data); // Execute SQL statement with data
            $this->db->commit(); // Commit transaction
            return true; // Return true
        } catch (PDOException $e) { // Catch any PDOException
            echo "Error: " . $e->getMessage(); // Echo error message
            $this->db->rollback(); // Rollback transaction
        }
    }

    public function delete($table, $where) // Delete method
    {
        $sql = "DELETE FROM $table $where"; // Construct SQL query
        $stmt = $this->db->prepare($sql); // Prepare SQL statement
        try { // Try executing SQL statement
            $stmt->execute(); // Execute SQL statement
            return true; // Return true
        } catch (PDOException $e) { // Catch any PDOException
            echo "Error: " . $e->getMessage(); // Echo error message
            $this->db->rollback(); // Rollback transaction
        }
    }
}
