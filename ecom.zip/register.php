<?php // Start PHP tag
//include required things // Including required files
include 'includes/header.php'; // Including header.php file
include 'includes/navbar.php'; // Including navbar.php file
?>
<!-- product detail page --> <!-- Start product detail page -->
<!-- Start card div -->
<div class="card">
    <!-- Start card-body div -->
    <div class="card-body">
        <!-- Start container div -->
        <div class="container">
            <!-- Registration header with some padding -->
            <h1 class="text-center py-5">Registration</h1>
            <!-- Start border div with padding -->
            <div class="border p-4">
                <!-- Registration form with POST method -->
                <form id="registractionForm" action="user_registration_action.php" method="post">
                    <!-- Start row div -->
                    <div class="row">
                        <!-- Column for first name -->
                        <div class="col-md-6 mb-3">
                            <!-- First name -->
                            <!-- Form group for first name -->
                            <div class="form-grpup">
                                <!-- Label for first name -->
                                <label for="first_name"><b>First Name</b></label>
                                <!-- Input field for first name -->
                                <input type="text" id="first_name" name="first_name" placeholder="First Name" class="form-control py-3" style="margin-top: 8px;">
                                <!-- Error message div for first name -->
                                <div class="text-danger" id="first_name_error"></div>
                            </div>
                        </div>

                        <!-- Last name -->
                        <!-- Column for last name -->
                        <div class="col-md-6 mb-3">
                            <!-- Form group for last name -->
                            <div class="form-grpup">
                                <!-- Label for last name -->
                                <label for="last_name"><b>Last Name</b></label>
                                <!-- Input field for last name -->
                                <input type="text" id="last_name" name="last_name" placeholder="Last Name" class="form-control py-3" style="margin-top: 8px;">
                                <!-- Error message div for last name -->
                                <div class="text-danger" id="last_name_error"></div>
                            </div>
                        </div>

                        <!-- Email -->
                        <!-- Column for email with top margin -->
                        <div class="col-md-6 mb-3" style="margin-top: 8px;">
                            <!-- Form group for email -->
                            <div class="form-grpup">
                                <!-- Label for email -->
                                <label for="email"><b>Email</b></label>
                                <!-- Input field for email -->
                                <input type="email" id="email" name="email" placeholder="Email" class="form-control py-3" style="margin-top: 8px;">
                                <!-- Error message div for email -->
                                <div class="text-danger" id="email_error"></div>
                            </div>
                        </div>

                        <!-- Mobile Number -->
                        <!-- Column for mobile number with top margin -->
                        <div class="col-md-6 mb-3" style="margin-top: 8px;">
                            <!-- Form group for mobile number -->
                            <div class="form-grpup">
                                <!-- Label for mobile number -->
                                <label for="mobile"><b>Mobile No.</b></label>
                                <!-- Input field for mobile number -->
                                <input type="tel" id="mobile" name="mobile" placeholder="Mobile No." class="form-control py-3" style="margin-top: 8px;">
                                <!-- Error message div for mobile number -->
                                <div class="text-danger" id="mobile_error"></div>
                            </div>
                        </div>

                        <!-- Password -->
                        <!-- Column for password with top margin -->
                        <div class="col-md-6 mb-3" style="margin-top: 8px;">
                            <!-- Form group for password -->
                            <div class="form-grpup">
                                <!-- Label for password -->
                                <label for="password"><b>Password</b></label>
                                <!-- Input field for password -->
                                <input type="password" id="password" name="password" placeholder="Please Enter Password" class="form-control py-3" style="margin-top: 8px;">
                                <!-- Error message div for password -->
                                <div class="text-danger" id="password_error"></div>
                            </div>
                        </div>

                        <!-- Comfirm Password -->
                        <!-- Column for confirm password with top margin -->
                        <div class="col-md-6 mb-3" style="margin-top: 8px;">
                            <!-- Form group for confirm password -->
                            <div class="form-grpup">
                                <!-- Label for confirm password -->
                                <label for="comfirm_password"><b>Comfirm Password</b></label>
                                <!-- Input field for confirm password -->
                                <input type="password" id="comfirm_password" name="comfirm_password" placeholder="Please Confirm your Password" class="form-control py-3" style="margin-top: 8px;">
                                <!-- Error message div for confirm password -->
                                <div class="text-danger" id="comfirm_password_error"></div>
                            </div>
                        </div>

                        <!-- Full width column for terms and conditions -->
                        <div class="col-md-12 mb-3">
                            <!-- Checkbox for terms and conditions -->
                            <input type="checkbox" id="terms" style="margin-top: 20px;">
                            <!-- Label for terms and conditions checkbox -->
                            <label for="terms">Agree with user's terms & conditions.</label>
                            <!-- Error message div for terms and conditions -->
                            <div class="text-danger" id="terms_error"></div>
                        </div>

                        <!-- Full width column for buttons, centered -->
                        <div class="col-md-12 d-flex justify-content-center">
                            <!-- Register button -->
                            <button type="submit" class="btn btn-primary btn-lg">Register</button>
                            <!-- Reset button with left margin -->
                            <button type="reset" class="btn btn-warning btn-lg ms-4 px-4">Reset</button>
                        </div>
                        <div>
                            <p class="text-center mt-4">Already have an account ? <a href="login.php">Click here for login</a></p>
                        </div>
                        <div class="col-md-12" id="message"></div>
                    </div> <!-- End row div -->
                </form> <!-- End form -->
            </div> <!-- End border div -->
        </div> <!-- End container div -->
    </div> <!-- End card-body div -->
</div> <!-- End card div -->

<!-- Include footer.php file -->
<?php include 'includes/footer.php'; ?>

<script>
    // jQuery document ready function
    $(document).ready(function() {
        // create function for user registration
        $("#registractionForm").on("submit", function(event) { // On form submit event

            // Prevent default form submission
            event.preventDefault();

            // clear all privious errors
            // Clear all previous error messages
            $('.text-danger').html("");

            // front end validation
            const fields = { // Collect form field values
                first_name: $("#first_name").val(),
                last_name: $("#last_name").val(),
                email: $("#email").val(),
                mobile: $("#mobile").val(),
                password: $("#password").val(),
                comfirm_password: $("#comfirm_password").val(),
                terms: $("#terms")
            }
            // console.log(fields);
            let valid = true; // Initialize validation flag

            const errors = {}; // Initialize errors object to store error messages

            if (fields.first_name.trim() === "") { // Validate first name
                valid = false; // Set validation flag to false
                errors.first_name_error = "First name is require"; // Set error message for first name
            }

            if (fields.last_name.trim() === "") { // Validate last name
                valid = false; // Set validation flag to false
                errors.last_name_error = "Last name is require"; // Set error message for last name
            }

            if (fields.email.trim() === "") { // Validate email
                valid = false; // Set validation flag to false
                errors.email_error = "Email is require"; // Set error message for email
            }

            if (fields.mobile.trim() === "") { // Validate mobile number
                valid = false; // Set validation flag to false
                errors.mobile_error = "Mobile Number is require"; // Set error message for mobile number
            }

            if (fields.password.trim() === "") { // Validate password
                valid = false; // Set validation flag to false
                errors.password_error = "Password field is require"; // Set error message for password
            }

            if (fields.comfirm_password.trim() === "") { // Validate confirm password
                valid = false; // Set validation flag to false
                errors.comfirm_password_error = "Comfirm Password field is require"; // Set error message for confirm password
            } else if (fields.comfirm_password !== fields.password) { // Check if passwords match
                valid = false; // Set validation flag to false
                errors.comfirm_password_error = "Password do not match."; // Set error message for password mismatch
            }

            if (!fields.terms.is(":checked")) { // Validate terms and conditions checkbox
                valid = false; // Set validation flag to false
                errors.terms_error = "You must agree with terms and conditions"; // Set error message for terms and conditions
            }

            // display errors
            if (!valid) { // If validation failed
                for (const [key, value] of Object.entries(errors)) { // Iterate through errors
                    // console.log("key name - ", key);
                    $("#" + key).html(value); // Display each error message in corresponding div
                }
                return; // Return without submitting the form
            }
            let fd = $("#registractionForm").serialize();
            // Create ajax request
            $.ajax({
                url: "action/user_registration_action.php",
                type: "POST",
                data: fd,
                dataType: "json",
                success: function(response) {
                    // console.log(response);
                    if (response.status == 'success') {
                        $("#message").html('<div class= "alert alert-success">' + response.message + '</div>');
                        $("#registractionForm")[0].reset();
                    }
                    if (response.status == false) {
                        // console.log(response.errors);
                        $.each(response.errors, function(key, value) {
                            $("#" + key).html(value);
                        })
                    }
                }
            })
        });
    });
</script> <!-- End of script -->