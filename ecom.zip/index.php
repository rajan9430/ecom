<?php // Start including header.php file
include 'includes/header.php'; // Include header.php file
include 'includes/navbar.php'; // Include navbar.php file
?>

<!-- slider area --> <!-- Start slider area -->
<div class="slider-area"> <!-- Start slider-area div -->
    <div class="slider"> <!-- Start slider div -->

    <?php // Start PHP foreach loop
            $fetch_latest_sliders = $obj->custom_get("sliders", " ORDER BY id DESC"); // Fetch latest products

            foreach ($fetch_latest_sliders as $latest_slider) :
                    ?>
        <div> <!-- Start first slide div -->
            <a href="<?= $latest_slider['buy_now_link']; ?>"> <!-- Start anchor tag -->
                <img src="uploads/images/slider/<?= $latest_slider['image']; ?>"> <!-- Image source -->
            </a> <!-- End anchor tag -->
            <!-- slider content --> <!-- Start slider content -->
            <div class="slider-content"> <!-- Start slider-content div -->
                <h3 class="text-white text-capitalize"><?= $latest_slider['title']; ?></h3> <!-- Heading -->
                <a href="<?= $latest_slider['buy_now_link']; ?>"><button class="btn btn-primary"><i class="fas fa-shopping-cart"></i> Buy Now</button></a> <!-- Buy Now button -->
                <a href="<?= $latest_slider['read_more_link']; ?>" style="margin-left: 30px;"><button class="btn btn-outline-danger">Read More</button></a> <!-- Read More button -->
            </div> <!-- End slider-content div -->
        </div> <!-- End first slide div -->
        <?php endforeach; ?> 
        
    </div> <!-- End slider div -->
</div> <!-- End slider-area div -->

<!-- this for work area --> <!-- Start work area -->
<div class="container-fluid"> <!-- Start container-fluid div -->
    <!-- product section --> <!-- Start product section -->
    <section class="product-section"> <!-- Start product-section section -->
        <div class="section-heading"> <!-- Start section-heading div -->
            <h3 class="heading"> Latest Products</h3> <!-- Heading -->
        </div> <!-- End section-heading div -->

        <div class="section-product-cards"> <!-- Start section-product-cards div -->

            <div class="owl-carousel"> <!-- Start owl-carousel div -->
                <?php // Start PHP foreach loop
                $fetch_latest_products = $obj->custom_get("products", " WHERE status = '1' ORDER BY product_id DESC"); // Fetch latest products

                foreach ($fetch_latest_products as $latest_product) : // Start foreach loop
                ?>
                    <div class="product-card"> <!-- Start product-card div -->
                        <div class="product-image"> <!-- Start product-image div -->
                            <img src="uploads/products/<?php echo $latest_product['product_thumbnail']; ?>" alt="product name"> <!-- Product image -->
                        </div> <!-- End product-image div -->

                        <!-- product hovered contents --> <!-- Start product hovered contents -->
                        <div class="card-contents"> <!-- Start card-contents div -->
                            <button type="button" class="btn btn-warning cart-btn product-add-cart-btn" data-product-id="<?php echo $latest_product['product_id']; ?>"> <!-- Cart button -->
                                <i class="fas fa-cart-plus"></i> <!-- Cart icon -->
                            </button> <!-- End button tag -->
                        </div> <!-- End card-contents div -->

                        <a href="product.php?product_id=<?php echo $latest_product['product_id']; ?>" style="text-decoration: none;"> <!-- Product link -->
                            <div class="product-details"> <!-- Start product-details div -->
                                <!-- product name --> <!-- Start product name -->
                                <h5 class="product-name" onmouseover="this.style.textDecoration='underline'" onmouseout="this.style.textDecoration='none'">
                                    <?php echo $latest_product['product_title']; ?> <!-- Product title -->
                                </h5> <!-- End product name -->
                                <p class="product-price"> <!-- Start product-price paragraph -->
                                    <small class="text-danger"><s><?php echo $latest_product['regular_price']; ?></s></small> <!-- Regular price -->
                                    <span class="text-success"><?php echo $latest_product['selling_price']; ?></span> <!-- Selling price -->
                                </p> <!-- End product-price paragraph -->
                            </div> <!-- End product-details div -->
                        </a> <!-- End anchor tag -->
                    </div> <!-- End product-card div -->
                <?php endforeach; ?> <!-- End PHP foreach loop -->
            </div> <!-- End owl-carousel div -->
        </div> <!-- End section-product-cards div -->
    </section> <!-- End product-section section -->
</div> <!-- End container-fluid div -->
<?php include 'includes/footer.php'; ?> <!-- Include footer.php file -->