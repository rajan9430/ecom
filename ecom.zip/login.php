<?php // Start PHP tag
session_start();
if (isset($_SESSION['loggedIn'])) {
    header('Location:index.php');
}
//include required things // Including required files
include 'includes/header.php'; // Including header.php file
include 'includes/navbar.php'; // Including navbar.php file
?>
<!-- product detail page --> <!-- Start product detail page -->
<!-- Start card div -->
<div class="card">
    <!-- Start card-body div -->
    <div class="card-body">
        <!-- Start container div -->
        <div class="container">
            <!-- Registration header with some padding -->
            <h1 class="text-center py-5">Login</h1>
            <!-- Start border div with padding -->
            <div class="border p-4 login-card">
                <!-- Registration form with POST method -->
                <form id="loginForm" action="user_registration_action.php" method="post">
                    <!-- Start row div -->
                    <div class="row">

                        <!-- Email -->
                        <!-- Column for email with top margin -->
                        <div class="col-md-12 mb-3" style="margin-top: 8px;">
                            <!-- Form group for email -->
                            <div class="form-grpup">
                                <!-- Label for email -->
                                <label for="email"><b>Email</b></label>
                                <!-- Input field for email -->
                                <input type="email" id="email" name="email" placeholder="Email" class="form-control py-3" style="margin-top: 8px;">
                                <!-- Error message div for email -->
                                <div class="text-danger" id="email_error"></div>
                            </div>
                        </div>

                        <!-- Password -->
                        <!-- Column for password with top margin -->
                        <div class="col-md-12 mb-3" style="margin-top: 8px;">
                            <!-- Form group for password -->
                            <div class="form-grpup">
                                <!-- Label for password -->
                                <label for="password"><b>Password</b></label>
                                <!-- Input field for password -->
                                <input type="password" id="password" name="password" placeholder="Please Enter Password" class="form-control py-3" style="margin-top: 8px;">
                                <!-- Error message div for password -->
                                <div class="text-danger" id="password_error"></div>
                            </div>
                        </div>

                        <!-- Full width column for buttons, centered -->
                        <div class="col-md-12 d-flex justify-content-center">
                            <!-- Register button -->
                            <button type="submit" class="btn btn-primary btn-lg">Login</button>
                        </div>

                        <div>
                            <p class="text-center mt-4">Don't have an account ? <a href="register.php">Create Account.</a></p>
                        </div>
                        <div class="col-md-12" id="message"></div>
                    </div> <!-- End row div -->
                </form> <!-- End form -->
            </div> <!-- End border div -->
        </div> <!-- End container div -->
    </div> <!-- End card-body div -->
</div> <!-- End card div -->


<!-- Include footer.php file -->
<?php include 'includes/footer.php'; ?>

<script>
    // jQuery document ready function
    $(document).ready(function() {
        // create function for user registration
        $("#loginForm").on("submit", function(event) { // On form submit event

            // Prevent default form submission
            event.preventDefault();

            // clear all privious errors
            // Clear all previous error messages
            $('.text-danger').html("");

            // front end validation
            const fields = { // Collect form field values   
                email: $("#email").val(),
                password: $("#password").val(),
            }
            // console.log(fields);
            let valid = true; // Initialize validation flag

            const errors = {}; // Initialize errors object to store error messages

            if (fields.email.trim() === "") { // Validate email
                valid = false; // Set validation flag to false
                errors.email_error = "Email is require"; // Set error message for email
            }

            if (fields.password.trim() === "") { // Validate password
                valid = false; // Set validation flag to false
                errors.password_error = "Password field is require"; // Set error message for password
            }
            // display errors
            if (!valid) { // If validation failed
                for (const [key, value] of Object.entries(errors)) { // Iterate through errors
                    // console.log("key name - ", key);
                    $("#" + key).html(value); // Display each error message in corresponding div
                }
                return; // Return without submitting the form
            }
            let fd = $("#loginForm").serialize();
            // Create ajax request
            $.ajax({
                url: "action/user_login_action.php",
                type: "POST",
                data: fd,
                dataType: "json",
                success: function(response) {
                    // console.log(response);
                    if (response.status == true) {
                        // $("#message").html('<div class= "alert alert-success">' + response.message + '</div>');
                        const toastLiveExample = document.getElementById('liveToast')
                        const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample)
                        $('.toast-message').text(response.message)
                        toastBootstrap.show()
                        $("#loginForm")[0].reset();

                        setTimeout(() => {
                            window.location.href = 'index.php';
                        }, 1000);
                    }
                    if (response.status == false) {
                        // console.log(response.errors);
                        $.each(response.errors, function(key, value) {
                            $("#" + key).html(value);
                        })
                    }
                }
            })
        });
    });
</script> <!-- End of script -->