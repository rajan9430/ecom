<div class="col-md-3">
            <div class="list-group">
                <a href="<?= $base_url; ?>account/index.php" class="list-group-item list-group-item-action active">
                    My Account
                </a>
                <a href="<?= $base_url; ?>account/orders.php" class="list-group-item list-group-item-action">My Orders</a>
                <a href="<?= $base_url; ?>account/account_details.php" class="list-group-item list-group-item-action">Account Details</a>
                <a href="change_password.php" class="list-group-item list-group-item-action">Change Password</a>
                <a href="<?= $base_url; ?>logout.php" class="list-group-item list-group-item-action text-danger">Log Out</a>
            </div>
        </div>