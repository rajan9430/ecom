<?php // Start PHP tag
//include required things // Including required files
include 'includes/header.php'; // Including header.php file
include 'includes/navbar.php'; // Including navbar.php file

$product_id = $_GET['product_id']; // Get product ID from URL parameter

$fetch_product = $obj->custom_get('products', " LEFT JOIN `category` ON `category`.`category_id` = `products`.`category_id` WHERE product_id = $product_id", 'fetch'); // Fetch product details

$regular_price = $fetch_product['regular_price']; // Regular price of the product
$selling_price = $fetch_product['selling_price']; // Selling price of the product

$price_difference = $regular_price - $selling_price; // Calculate price difference
$discount_in_percentage = ($price_difference / $regular_price) * 100; // Calculate discount in percentage
// $discount_in_percentage = intval($discount_in_percentage); // Convert discount to integer value
// echo '<pre>';print_r($fetch_product); // Print fetched product details
// die(); // Stop execution

?>
<!-- product detail page --> <!-- Start product detail page -->
<div class="card"> <!-- Start card div -->
    <div class="card-body"> <!-- Start card-body div -->
        <div class="container"> <!-- Start container div -->
            <div class="row product-custom-row"> <!-- Start row div -->
                <div class="col-md-6"> <!-- Start column div -->
                    <div class="product_details_image"> <!-- Start product_details_image div -->
                        <img src="uploads/products/<?php echo $fetch_product['product_thumbnail']; ?>" class="img-fluid large-image"> <!-- Product image -->
                    </div> <!-- End product_details_image div -->
                </div> <!-- End column div -->

                <div class="col-md-6"> <!-- Start column div -->
                    <div style="background-color: black; padding: 5px; width: 100px; text-align: center; border-radius: 5px 5px 5px 5px; font-weight: bold;"> <!-- Category label -->
                        <span style="color: white;"><?php echo $fetch_product['category_name']; ?></span> <!-- Category name -->
                    </div> <!-- End category label -->
                    <div class="product-detail-title"> <!-- Start product-detail-title div -->
                        <h1><?php echo $fetch_product['product_title']; ?></h1> <!-- Product title -->
                    </div> <!-- End product-detail-title div -->
                    <div class="product-detail-short-description"> <!-- Start product-detail-short-description div -->
                        <p><?php echo $fetch_product['short_description']; ?></p> <!-- Short description -->
                    </div> <!-- End product-detail-short-description div -->
                    <div class="product-detail-price"> <!-- Start product-detail-price div -->
                        <span class="font-weight-bold" style="font-weight: bold;">-<?php echo round($discount_in_percentage, 0); ?>%</span> <!-- Discount percentage -->
                        <span class="Selling-price">$<?php echo $fetch_product['selling_price']; ?></span> <!-- Selling price -->
                        <span class="Regular-price"><del class="text-danger">$<?php echo $fetch_product['regular_price']; ?></del></span> <!-- Regular price -->
                    </div> <!-- End product-detail-price div -->

                    <button type="button" class="btn btn-dark btn-lg product-add-cart-btn" data-product-id="<?php echo $fetch_product['product_id']; ?>">
                        <i class="fas fa-cart-plus"></i> Add to cart</button>

                </div> <!-- End column div -->

                <div class="col-md-12 mt-5"> <!-- Start column div -->
                    <h2>Description</h2> <!-- Description heading -->
                    <hr> <!-- Horizontal line -->
                    <p class="product-detail-long-description"><?php echo $fetch_product['long_description']; ?></p> <!-- Long description -->
                </div> <!-- End column div -->
            </div> <!-- End row div -->
        </div> <!-- End container div -->
    </div> <!-- End card-body div -->
</div> <!-- End card div -->
<?php include 'includes/footer.php'; ?> <!-- Include footer.php file -->